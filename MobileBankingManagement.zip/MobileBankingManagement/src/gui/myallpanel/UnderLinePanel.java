package gui.myallpanel;

import javax.swing.*;
import java.awt.*;

public class UnderLinePanel extends JPanel {
    public UnderLinePanel(){
        setLayout(null);
        setBounds(0,150,600,5);
        setBackground(Color.RED);

    }
}
